# Terminology

### ActionMethod
Action methods are the exposed API methods defined on controller.
Dinoloop treats a method as action method when it is decorated with http verbs like *@HttpGet, @HttpPost ...*.
### Dinoware
Dinowares are middlewares that extend classes of Dinoloop. 
