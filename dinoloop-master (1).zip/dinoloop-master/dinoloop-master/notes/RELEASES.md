# Releases Planned

### Future releases

1. Validators in IControllerAttribute to handle validation errors added by IParseHandlers.
2. Middlewares at action level.
3. Interceptors support using @InterceptBy.
4. Async version of ApplicationStart middleware.
