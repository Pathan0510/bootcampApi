export class User {
    name: 'dino';
}
