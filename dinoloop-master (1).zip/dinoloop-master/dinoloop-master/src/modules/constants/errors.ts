export const Errors = {
    dinoAlreadyBinded: 'dino.bind(): Already invoked',
    routerNotRegistered: 'Express router is not registered with dino',
    baseUriInvalid: 'Invalid baseUri to mount the dino app'
};
