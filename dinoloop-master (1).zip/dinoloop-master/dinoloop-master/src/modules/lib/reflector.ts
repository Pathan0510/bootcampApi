// refer: https://github.com/rbuckton/reflect-metadata
import 'reflect-metadata';

export const Reflector = Reflect;
