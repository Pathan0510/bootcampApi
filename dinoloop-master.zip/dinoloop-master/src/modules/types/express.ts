/**** Comment these exports while publishing to NPM ****/
// tslint:disable-next-line:no-implicit-dependencies
import { Express, Router, Request, Response, NextFunction } from 'express';
export type Express = Express;
export type Router = Router;
export type Request = Request;
export type Response = Response;
export type NextFunction = NextFunction;
/******************************************************/

/**** UnComment these exports while publishing to NPM ****/
// export type Express = any;
// export type Router = any;
// export type Request = any;
// export type Response = any;
// export type NextFunction = any;
/********************************************************/
